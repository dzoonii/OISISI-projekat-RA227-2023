namespace SajamKnjiga.Models;

public class Izdavac : Entitet
{
    public string Sifra { get; set; } = "";
    public string Naziv { get; set; } = "";
    public int SefId { get; set; }   // Id autora sa najmanje 5 godina iskustva
}
