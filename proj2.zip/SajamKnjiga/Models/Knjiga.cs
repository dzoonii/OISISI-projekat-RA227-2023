namespace SajamKnjiga.Models;

public class Knjiga : Entitet
{
    public string Isbn { get; set; } = "";
    public string Naziv { get; set; } = "";
    public string Zanr { get; set; } = "";
    public int GodinaIzdanja { get; set; }
    public decimal Cena { get; set; }
    public int BrojStrana { get; set; }
    public int IzdavacId { get; set; }
    public List<int> AutoriIds { get; set; } = new();
}
