using SajamKnjiga.Meniji;

// Glavni meni: bira se entitet, pa se otvara podmeni sa 4 funkcionalnosti (8.1 - 8.4).
while (true)
{
    Console.WriteLine("\n===== SAJAM KNJIGA =====");
    Console.WriteLine("1 - Posetioci");
    Console.WriteLine("2 - Autori");
    Console.WriteLine("3 - Knjige");
    Console.WriteLine("4 - Kupovine");
    Console.WriteLine("5 - Izdavaci");
    Console.WriteLine("6 - Adrese");
    Console.WriteLine("0 - Izlaz");
    Console.Write("Izbor: ");

    switch (Console.ReadLine())
    {
        case "1": Podmeni("POSETIOCI", PosetilacMeni.Prikazi, PosetilacMeni.Dodaj, PosetilacMeni.Izmeni, PosetilacMeni.Obrisi); break;
        case "2": Podmeni("AUTORI", AutorMeni.Prikazi, AutorMeni.Dodaj, AutorMeni.Izmeni, AutorMeni.Obrisi); break;
        case "3": Podmeni("KNJIGE", KnjigaMeni.Prikazi, KnjigaMeni.Dodaj, KnjigaMeni.Izmeni, KnjigaMeni.Obrisi); break;
        case "4": Podmeni("KUPOVINE", KupovinaMeni.Prikazi, KupovinaMeni.Dodaj, KupovinaMeni.Izmeni, KupovinaMeni.Obrisi); break;
        case "5": Podmeni("IZDAVACI", IzdavacMeni.Prikazi, IzdavacMeni.Dodaj, IzdavacMeni.Izmeni, IzdavacMeni.Obrisi); break;
        case "6": Podmeni("ADRESE", AdresaMeni.Prikazi, AdresaMeni.Dodaj, AdresaMeni.Izmeni, AdresaMeni.Obrisi); break;
        case "0": return;   // podaci su vec sacuvani posle svake izmene
        default: Console.WriteLine("Nepoznata opcija."); break;
    }
}

static void Podmeni(string naslov, Action prikazi, Action dodaj, Action izmeni, Action obrisi)
{
    while (true)
    {
        Console.WriteLine($"\n--- {naslov} ---");
        Console.WriteLine("1 - Prikaz");
        Console.WriteLine("2 - Dodavanje");
        Console.WriteLine("3 - Izmena");
        Console.WriteLine("4 - Brisanje");
        Console.WriteLine("0 - Nazad");
        Console.Write("Izbor: ");
        string izbor = Console.ReadLine() ?? "";
        if (izbor == "0") return;

        try
        {
            switch (izbor)
            {
                case "1": prikazi(); break;
                case "2": dodaj(); break;
                case "3": izmeni(); break;
                case "4": obrisi(); break;
                default: Console.WriteLine("Nepoznata opcija."); break;
            }
        }
        catch (InvalidOperationException ex)
        {
            Console.WriteLine("Greska: " + ex.Message);
        }
    }
}
