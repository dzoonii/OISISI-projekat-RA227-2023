using SajamKnjiga.Models;

namespace SajamKnjiga.Dao;

// Na jednom mestu su svih 6 DAO objekata (po jedan fajl za svaki entitet).
public static class Podaci
{
    public static JsonDao<Adresa> Adrese { get; } = new("adrese.json");
    public static JsonDao<Autor> Autori { get; } = new("autori.json");
    public static JsonDao<Izdavac> Izdavaci { get; } = new("izdavaci.json");
    public static JsonDao<Knjiga> Knjige { get; } = new("knjige.json");
    public static JsonDao<Posetilac> Posetioci { get; } = new("posetioci.json");
    public static JsonDao<Kupovina> Kupovine { get; } = new("kupovine.json");
}
