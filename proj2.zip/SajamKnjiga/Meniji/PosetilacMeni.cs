using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class PosetilacMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Posetioci.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema posetilaca."); return; }
        Console.WriteLine("ID | Ime | Prezime | Rodjen | AdresaID | Telefon | Email | Clanska karta | God. clanstva | Status | Prosek");
        foreach (var p in lista)
            Console.WriteLine($"{p.Id} | {p.Ime} | {p.Prezime} | {p.DatumRodjenja:dd.MM.yyyy} | {p.AdresaId} | {p.Telefon} | {p.Email} | {p.BrojClanskeKarte} | {p.GodinaClanstva} | {p.Status} | {p.ProsecnaOcena:F2}");
    }

    private static bool AdresaPostoji(int id) => Podaci.Adrese.GetById(id) != null;

    public static void Dodaj()
    {
        var p = new Posetilac
        {
            Ime = Unos.Tekst("Ime"),
            Prezime = Unos.Tekst("Prezime"),
            DatumRodjenja = Unos.Datum("Datum rodjenja"),
            AdresaId = Unos.PostojeciId("ID adrese", AdresaPostoji),
            Telefon = Unos.Tekst("Telefon"),
            Email = Unos.Tekst("Email"),
            BrojClanskeKarte = Unos.Tekst("Broj clanske karte (npr. CK-1-2023)"),
            GodinaClanstva = Unos.Ceo("Tekuca godina clanstva", null, 1900, 2100),
            Status = Unos.Status()
        };
        Podaci.Posetioci.Add(p);
        Console.WriteLine($"Posetilac dodat (ID {p.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID posetioca za izmenu", null, 1);
        var p = Podaci.Posetioci.GetById(id);
        if (p == null) { Console.WriteLine("Posetilac ne postoji."); return; }

        p.Ime = Unos.Tekst("Ime", p.Ime);
        p.Prezime = Unos.Tekst("Prezime", p.Prezime);
        p.DatumRodjenja = Unos.Datum("Datum rodjenja", p.DatumRodjenja);
        p.AdresaId = Unos.PostojeciId("ID adrese", AdresaPostoji, p.AdresaId);
        p.Telefon = Unos.Tekst("Telefon", p.Telefon);
        p.Email = Unos.Tekst("Email", p.Email);
        p.BrojClanskeKarte = Unos.Tekst("Broj clanske karte", p.BrojClanskeKarte);
        p.GodinaClanstva = Unos.Ceo("Tekuca godina clanstva", p.GodinaClanstva, 1900, 2100);
        p.Status = Unos.Status(p.Status);
        Podaci.Posetioci.Update(p);
        Console.WriteLine("Posetilac izmenjen.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID posetioca za brisanje", null, 1);
        if (Podaci.Kupovine.GetAll().Any(k => k.PosetilacId == id))
            throw new InvalidOperationException("Posetilac ima kupovine, ne moze se obrisati.");

        Console.WriteLine(Podaci.Posetioci.Delete(id) ? "Posetilac obrisan." : "Posetilac ne postoji.");
    }
}
