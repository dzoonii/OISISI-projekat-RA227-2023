using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class IzdavacMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Izdavaci.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema izdavaca."); return; }
        Console.WriteLine("ID | Sifra | Naziv | Sef (autor)");
        foreach (var i in lista)
        {
            var sef = Podaci.Autori.GetById(i.SefId);
            string imeSefa = sef == null ? "?" : $"{sef.Ime} {sef.Prezime}";
            Console.WriteLine($"{i.Id} | {i.Sifra} | {i.Naziv} | {i.SefId} ({imeSefa})");
        }
    }

    // Sef mora biti postojeci autor sa najmanje 5 godina iskustva.
    private static int UnesiSefa(int? staro = null)
    {
        while (true)
        {
            int id = Unos.PostojeciId("ID sefa (autor sa min. 5 god. iskustva)",
                x => Podaci.Autori.GetById(x) != null, staro);
            if (Podaci.Autori.GetById(id)!.GodineIskustva >= 5) return id;
            Console.WriteLine("Taj autor ima manje od 5 godina iskustva.");
        }
    }

    public static void Dodaj()
    {
        var i = new Izdavac
        {
            Sifra = Unos.Tekst("Sifra"),
            Naziv = Unos.Tekst("Naziv"),
            SefId = UnesiSefa()
        };
        Podaci.Izdavaci.Add(i);
        Console.WriteLine($"Izdavac dodat (ID {i.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID izdavaca za izmenu", null, 1);
        var i = Podaci.Izdavaci.GetById(id);
        if (i == null) { Console.WriteLine("Izdavac ne postoji."); return; }

        i.Sifra = Unos.Tekst("Sifra", i.Sifra);
        i.Naziv = Unos.Tekst("Naziv", i.Naziv);
        i.SefId = UnesiSefa(i.SefId);
        Podaci.Izdavaci.Update(i);
        Console.WriteLine("Izdavac izmenjen.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID izdavaca za brisanje", null, 1);
        if (Podaci.Knjige.GetAll().Any(k => k.IzdavacId == id))
            throw new InvalidOperationException("Izdavac ima knjige, ne moze se obrisati.");

        Console.WriteLine(Podaci.Izdavaci.Delete(id) ? "Izdavac obrisan." : "Izdavac ne postoji.");
    }
}
