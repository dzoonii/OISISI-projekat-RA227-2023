using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class KnjigaMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Knjige.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema knjiga."); return; }
        Console.WriteLine("ID | ISBN | Naziv | Zanr | Godina | Cena | Strana | IzdavacID | AutoriID");
        foreach (var k in lista)
            Console.WriteLine($"{k.Id} | {k.Isbn} | {k.Naziv} | {k.Zanr} | {k.GodinaIzdanja} | {k.Cena} | {k.BrojStrana} | {k.IzdavacId} | {string.Join(",", k.AutoriIds)}");
    }

    private static bool IzdavacPostoji(int id) => Podaci.Izdavaci.GetById(id) != null;
    private static bool AutorPostoji(int id) => Podaci.Autori.GetById(id) != null;

    public static void Dodaj()
    {
        var k = new Knjiga
        {
            Isbn = Unos.Tekst("ISBN"),
            Naziv = Unos.Tekst("Naziv"),
            Zanr = Unos.Tekst("Zanr"),
            GodinaIzdanja = Unos.Ceo("Godina izdanja", null, 1000, 2100),
            Cena = Unos.Decimalni("Cena"),
            BrojStrana = Unos.Ceo("Broj strana", null, 1, 10000),
            IzdavacId = Unos.PostojeciId("ID izdavaca", IzdavacPostoji),
            AutoriIds = Unos.ListaIdeva("ID-evi autora", AutorPostoji)
        };
        Podaci.Knjige.Add(k);
        Console.WriteLine($"Knjiga dodata (ID {k.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID knjige za izmenu", null, 1);
        var k = Podaci.Knjige.GetById(id);
        if (k == null) { Console.WriteLine("Knjiga ne postoji."); return; }

        k.Isbn = Unos.Tekst("ISBN", k.Isbn);
        k.Naziv = Unos.Tekst("Naziv", k.Naziv);
        k.Zanr = Unos.Tekst("Zanr", k.Zanr);
        k.GodinaIzdanja = Unos.Ceo("Godina izdanja", k.GodinaIzdanja, 1000, 2100);
        k.Cena = Unos.Decimalni("Cena", k.Cena);
        k.BrojStrana = Unos.Ceo("Broj strana", k.BrojStrana, 1, 10000);
        k.IzdavacId = Unos.PostojeciId("ID izdavaca", IzdavacPostoji, k.IzdavacId);
        k.AutoriIds = Unos.ListaIdeva("ID-evi autora", AutorPostoji, k.AutoriIds);
        Podaci.Knjige.Update(k);
        Console.WriteLine("Knjiga izmenjena.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID knjige za brisanje", null, 1);
        if (Podaci.Kupovine.GetAll().Any(x => x.KnjigaId == id))
            throw new InvalidOperationException("Knjiga je kupljena, ne moze se obrisati.");
        if (Podaci.Posetioci.GetAll().Any(p => p.ListaZeljaKnjigaIds.Contains(id)))
            throw new InvalidOperationException("Knjiga je na listi zelja nekog posetioca, ne moze se obrisati.");

        Console.WriteLine(Podaci.Knjige.Delete(id) ? "Knjiga obrisana." : "Knjiga ne postoji.");
    }
}
