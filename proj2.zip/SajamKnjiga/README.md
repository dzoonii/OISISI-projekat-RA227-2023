# Sajam knjiga - prvi domaci zadatak

Konzolna C# aplikacija (.NET 8). Podaci se cuvaju u JSON fajlovima (folder `Podaci`, pored izvrsnog fajla).

## Struktura
- `Models/` - 6 entiteta (Posetilac, Autor, Knjiga, Kupovina, Izdavac, Adresa) + enum `StatusPosetioca`
- `Dao/JsonDao.cs` - serijalizacija i deserijalizacija (jedan fajl po entitetu)
- `Dao/Podaci.cs` - svih 6 DAO objekata na jednom mestu
- `Meniji/` - prikaz, dodavanje, izmena i brisanje za svaki entitet (8.1 - 8.4)
- `Unos.cs` - pomocne metode za unos i proveru podataka
- `Program.cs` - glavni meni

## Podela posla
- Student 1: Posetilac, Kupovina, Izdavac
- Student 2: Autor, Knjiga, Adresa
(upisati imena)

## Pokretanje
`dotnet run`
