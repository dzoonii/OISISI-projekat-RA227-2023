using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class KupovinaMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Kupovine.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema kupovina."); return; }
        Console.WriteLine("ID | PosetilacID | KnjigaID | Datum | Ocena | Komentar");
        foreach (var k in lista)
            Console.WriteLine($"{k.Id} | {k.PosetilacId} | {k.KnjigaId} | {k.DatumKupovine:dd.MM.yyyy} | {k.Ocena} | {k.Komentar}");
    }

    private static bool PosetilacPostoji(int id) => Podaci.Posetioci.GetById(id) != null;
    private static bool KnjigaPostoji(int id) => Podaci.Knjige.GetById(id) != null;

    // Prosecna ocena posetioca = prosek ocena svih njegovih kupovina.
    private static void OsveziProsek(int posetilacId)
    {
        var posetilac = Podaci.Posetioci.GetById(posetilacId);
        if (posetilac == null) return;
        var ocene = Podaci.Kupovine.GetAll().Where(k => k.PosetilacId == posetilacId).Select(k => k.Ocena).ToList();
        posetilac.ProsecnaOcena = ocene.Count == 0 ? 0 : ocene.Average();
        Podaci.Posetioci.Update(posetilac);
    }

    public static void Dodaj()
    {
        var k = new Kupovina
        {
            PosetilacId = Unos.PostojeciId("ID posetioca", PosetilacPostoji),
            KnjigaId = Unos.PostojeciId("ID knjige", KnjigaPostoji),
            DatumKupovine = Unos.Datum("Datum kupovine"),
            Ocena = Unos.Ceo("Ocena (1-5)", null, 1, 5),
            Komentar = Unos.Tekst("Komentar")
        };
        Podaci.Kupovine.Add(k);
        OsveziProsek(k.PosetilacId);
        Console.WriteLine($"Kupovina dodata (ID {k.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID kupovine za izmenu", null, 1);
        var k = Podaci.Kupovine.GetById(id);
        if (k == null) { Console.WriteLine("Kupovina ne postoji."); return; }

        int stariPosetilac = k.PosetilacId;
        k.PosetilacId = Unos.PostojeciId("ID posetioca", PosetilacPostoji, k.PosetilacId);
        k.KnjigaId = Unos.PostojeciId("ID knjige", KnjigaPostoji, k.KnjigaId);
        k.DatumKupovine = Unos.Datum("Datum kupovine", k.DatumKupovine);
        k.Ocena = Unos.Ceo("Ocena (1-5)", k.Ocena, 1, 5);
        k.Komentar = Unos.Tekst("Komentar", k.Komentar);
        Podaci.Kupovine.Update(k);
        OsveziProsek(stariPosetilac);
        OsveziProsek(k.PosetilacId);
        Console.WriteLine("Kupovina izmenjena.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID kupovine za brisanje", null, 1);
        var k = Podaci.Kupovine.GetById(id);
        if (k == null) { Console.WriteLine("Kupovina ne postoji."); return; }

        Podaci.Kupovine.Delete(id);
        OsveziProsek(k.PosetilacId);
        Console.WriteLine("Kupovina obrisana.");
    }
}
