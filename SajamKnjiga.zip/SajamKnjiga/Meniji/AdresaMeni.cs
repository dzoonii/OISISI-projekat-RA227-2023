using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class AdresaMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Adrese.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema adresa."); return; }
        Console.WriteLine("ID | Ulica | Broj | Grad | Drzava");
        foreach (var a in lista)
            Console.WriteLine($"{a.Id} | {a.Ulica} | {a.Broj} | {a.Grad} | {a.Drzava}");
    }

    public static void Dodaj()
    {
        var a = new Adresa
        {
            Ulica = Unos.Tekst("Ulica"),
            Broj = Unos.Tekst("Broj"),
            Grad = Unos.Tekst("Grad"),
            Drzava = Unos.Tekst("Drzava")
        };
        Podaci.Adrese.Add(a);
        Console.WriteLine($"Adresa dodata (ID {a.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID adrese za izmenu", null, 1);
        var a = Podaci.Adrese.GetById(id);
        if (a == null) { Console.WriteLine("Adresa ne postoji."); return; }

        a.Ulica = Unos.Tekst("Ulica", a.Ulica);
        a.Broj = Unos.Tekst("Broj", a.Broj);
        a.Grad = Unos.Tekst("Grad", a.Grad);
        a.Drzava = Unos.Tekst("Drzava", a.Drzava);
        Podaci.Adrese.Update(a);
        Console.WriteLine("Adresa izmenjena.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID adrese za brisanje", null, 1);
        // referencijalna zavisnost: adresu ne smemo obrisati ako je neko koristi
        if (Podaci.Posetioci.GetAll().Any(p => p.AdresaId == id) ||
            Podaci.Autori.GetAll().Any(a => a.AdresaId == id))
            throw new InvalidOperationException("Adresa se koristi (posetilac ili autor), ne moze se obrisati.");

        Console.WriteLine(Podaci.Adrese.Delete(id) ? "Adresa obrisana." : "Adresa ne postoji.");
    }
}
