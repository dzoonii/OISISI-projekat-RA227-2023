using SajamKnjiga.Dao;
using SajamKnjiga.Models;

namespace SajamKnjiga.Meniji;

public static class AutorMeni
{
    public static void Prikazi()
    {
        var lista = Podaci.Autori.GetAll();
        if (lista.Count == 0) { Console.WriteLine("Nema autora."); return; }
        Console.WriteLine("ID | Ime | Prezime | Rodjen | Adresa | Telefon | Email | LK | God. iskustva | Knjige");
        foreach (var a in lista)
            Console.WriteLine($"{a.Id} | {a.Ime} | {a.Prezime} | {a.DatumRodjenja:dd.MM.yyyy} | {Podaci.AdresaTekst(a.AdresaId)} | {a.Telefon} | {a.Email} | {a.BrojLicneKarte} | {a.GodineIskustva} | {string.Join("; ", a.Knjige.Select(k => k.Naziv))}");
    }

    private static bool AdresaPostoji(int id) => Podaci.Adrese.GetById(id) != null;

    public static void Dodaj()
    {
        var a = new Autor
        {
            Ime = Unos.Tekst("Ime"),
            Prezime = Unos.Tekst("Prezime"),
            DatumRodjenja = Unos.Datum("Datum rodjenja"),
            AdresaId = Unos.PostojeciId("ID adrese", AdresaPostoji),
            Telefon = Unos.Tekst("Telefon"),
            Email = Unos.Tekst("Email"),
            BrojLicneKarte = Unos.Tekst("Broj licne karte"),
            GodineIskustva = Unos.Ceo("Godine iskustva", null, 0, 80)
        };
        Podaci.Autori.Add(a);
        Console.WriteLine($"Autor dodat (ID {a.Id}).");
    }

    public static void Izmeni()
    {
        int id = Unos.Ceo("ID autora za izmenu", null, 1);
        var a = Podaci.Autori.GetById(id);
        if (a == null) { Console.WriteLine("Autor ne postoji."); return; }

        a.Ime = Unos.Tekst("Ime", a.Ime);
        a.Prezime = Unos.Tekst("Prezime", a.Prezime);
        a.DatumRodjenja = Unos.Datum("Datum rodjenja", a.DatumRodjenja);
        a.AdresaId = Unos.PostojeciId("ID adrese", AdresaPostoji, a.AdresaId);
        a.Telefon = Unos.Tekst("Telefon", a.Telefon);
        a.Email = Unos.Tekst("Email", a.Email);
        a.BrojLicneKarte = Unos.Tekst("Broj licne karte", a.BrojLicneKarte);
        a.GodineIskustva = Unos.Ceo("Godine iskustva", a.GodineIskustva, 0, 80);
        Podaci.Autori.Update(a);
        Console.WriteLine("Autor izmenjen.");
    }

    public static void Obrisi()
    {
        int id = Unos.Ceo("ID autora za brisanje", null, 1);
        if (Podaci.Knjige.GetAll().Any(k => k.AutoriIds.Contains(id)))
            throw new InvalidOperationException("Autor ima knjige, ne moze se obrisati.");
        if (Podaci.Izdavaci.GetAll().Any(i => i.SefId == id))
            throw new InvalidOperationException("Autor je sef izdavaca, ne moze se obrisati.");

        Console.WriteLine(Podaci.Autori.Delete(id) ? "Autor obrisan." : "Autor ne postoji.");
    }
}
