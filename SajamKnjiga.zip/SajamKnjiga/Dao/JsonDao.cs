using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using SajamKnjiga.Models;

namespace SajamKnjiga.Dao;

// Jedna klasa koja cuva bilo koji entitet u JSON fajl.
// <T> je tip entiteta (Adresa, Autor...). T mora biti Entitet (da ima Id).
public class JsonDao<T> where T : Entitet
{
    private static readonly JsonSerializerOptions Opcije = new()
    {
        WriteIndented = true,                                  // lep, uvucen JSON
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping, // č, ć, š, ž, đ ostaju citljiva
        Converters = { new JsonStringEnumConverter() }         // enum kao tekst (R / V)
    };

    private readonly string _putanja;
    private List<T> _lista;

    public JsonDao(string imeFajla)
    {
        // Path.Combine koristi pravi separator (Path.DirectorySeparatorChar)
        string folder = Path.Combine(AppContext.BaseDirectory, "Podaci");
        Directory.CreateDirectory(folder);
        _putanja = Path.Combine(folder, imeFajla);
        _lista = Ucitaj();   // DESERIJALIZACIJA pri pokretanju
    }

    public List<T> GetAll() => _lista;

    public T? GetById(int id) => _lista.FirstOrDefault(e => e.Id == id);

    public void Add(T entitet)
    {
        entitet.Id = _lista.Count == 0 ? 1 : _lista.Max(e => e.Id) + 1;
        _lista.Add(entitet);
        Sacuvaj();
    }

    public void Update(T entitet)
    {
        int indeks = _lista.FindIndex(e => e.Id == entitet.Id);
        if (indeks < 0) throw new InvalidOperationException("Entitet ne postoji.");
        _lista[indeks] = entitet;
        Sacuvaj();
    }

    public bool Delete(int id)
    {
        bool obrisan = _lista.RemoveAll(e => e.Id == id) > 0;
        if (obrisan) Sacuvaj();
        return obrisan;
    }

    // SERIJALIZACIJA: lista objekata -> JSON tekst -> fajl
    private void Sacuvaj()
    {
        File.WriteAllText(_putanja, JsonSerializer.Serialize(_lista, Opcije));
    }

    // DESERIJALIZACIJA: fajl -> JSON tekst -> lista objekata
    private List<T> Ucitaj()
    {
        if (!File.Exists(_putanja)) return new List<T>();
        string json = File.ReadAllText(_putanja);
        return JsonSerializer.Deserialize<List<T>>(json, Opcije) ?? new List<T>();
    }
}
