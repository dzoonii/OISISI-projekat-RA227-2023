using SajamKnjiga.Models;

namespace SajamKnjiga.Dao;

// Na jednom mestu su svih 6 DAO objekata (po jedan fajl za svaki entitet).
public static class Podaci
{
    public static JsonDao<Adresa> Adrese { get; } = new("adrese.json");
    public static JsonDao<Autor> Autori { get; } = new("autori.json");
    public static JsonDao<Izdavac> Izdavaci { get; } = new("izdavaci.json");
    public static JsonDao<Knjiga> Knjige { get; } = new("knjige.json");
    public static JsonDao<Posetilac> Posetioci { get; } = new("posetioci.json");
    public static JsonDao<Kupovina> Kupovine { get; } = new("kupovine.json");

    // Popunjava liste u modelima (Kupovine, Knjige, Kupci...) iz ID-eva.
    // Poziva se pri pokretanju i posle svake akcije u meniju.
    public static void Osvezi()
    {
        foreach (var p in Posetioci.GetAll())
        {
            p.Kupovine = Kupovine.GetAll().Where(k => k.PosetilacId == p.Id).ToList();
            p.ListaZelja = Knjige.GetAll().Where(k => p.ListaZeljaKnjigaIds.Contains(k.Id)).ToList();
        }

        foreach (var a in Autori.GetAll())
            a.Knjige = Knjige.GetAll().Where(k => k.AutoriIds.Contains(a.Id)).ToList();

        foreach (var k in Knjige.GetAll())
        {
            k.Kupci = Kupovine.GetAll()
                .Where(x => x.KnjigaId == k.Id)
                .Select(x => Posetioci.GetById(x.PosetilacId))
                .OfType<Posetilac>()
                .Distinct()
                .ToList();
            k.ZeljeliPosetioci = Posetioci.GetAll().Where(p => p.ListaZeljaKnjigaIds.Contains(k.Id)).ToList();
        }

        foreach (var i in Izdavaci.GetAll())
        {
            i.Knjige = Knjige.GetAll().Where(k => k.IzdavacId == i.Id).ToList();
            i.Autori = i.Knjige
                .SelectMany(k => k.AutoriIds)
                .Distinct()
                .Select(id => Autori.GetById(id))
                .OfType<Autor>()
                .ToList();
        }
    }

    // Citljiv tekst adrese za prikaz (umesto golog ID-a).
    public static string AdresaTekst(int adresaId)
    {
        var a = Adrese.GetById(adresaId);
        return a == null ? "?" : $"{a.Ulica} {a.Broj}, {a.Grad}";
    }
}
