using System.Globalization;
using SajamKnjiga.Models;

namespace SajamKnjiga;

// Pomocne metode za unos iz konzole. Ako je zadata "staro" vrednost (izmena),
// pritisak na Enter ostavlja staru vrednost.
public static class Unos
{
    private static string Citaj(string naziv, string? staro)
    {
        Console.Write(staro == null ? $"{naziv}: " : $"{naziv} [{staro}]: ");
        return (Console.ReadLine() ?? "").Trim();
    }

    public static string Tekst(string naziv, string? staro = null)
    {
        while (true)
        {
            string s = Citaj(naziv, staro);
            if (s != "") return s;
            if (staro != null) return staro;
            Console.WriteLine("Polje ne sme biti prazno.");
        }
    }

    public static int Ceo(string naziv, int? staro = null, int min = 0, int max = 100000)
    {
        while (true)
        {
            string s = Citaj(naziv, staro?.ToString());
            if (s == "" && staro != null) return staro.Value;
            if (int.TryParse(s, out int broj) && broj >= min && broj <= max) return broj;
            Console.WriteLine($"Unesite ceo broj od {min} do {max}.");
        }
    }

    public static decimal Decimalni(string naziv, decimal? staro = null)
    {
        while (true)
        {
            string s = Citaj(naziv, staro?.ToString(CultureInfo.InvariantCulture));
            if (s == "" && staro != null) return staro.Value;
            if (decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal d) && d >= 0)
                return d;
            Console.WriteLine("Unesite pozitivan broj (npr. 1500.50).");
        }
    }

    public static DateTime Datum(string naziv, DateTime? staro = null)
    {
        while (true)
        {
            string s = Citaj(naziv + " (dd.MM.yyyy)", staro?.ToString("dd.MM.yyyy"));
            if (s == "" && staro != null) return staro.Value;
            if (DateTime.TryParseExact(s, "dd.MM.yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime d))
                return d;
            Console.WriteLine("Datum mora biti u formatu dd.MM.yyyy (npr. 25.12.2000).");
        }
    }

    public static StatusPosetioca Status(StatusPosetioca? staro = null)
    {
        while (true)
        {
            string s = Citaj("Status (R - redovan, V - VIP)", staro?.ToString()).ToUpper();
            if (s == "" && staro != null) return staro.Value;
            if (s == "R") return StatusPosetioca.R;
            if (s == "V") return StatusPosetioca.V;
            Console.WriteLine("Unesite R ili V.");
        }
    }

    // Trazi Id dok korisnik ne unese Id koji stvarno postoji.
    public static int PostojeciId(string naziv, Func<int, bool> postoji, int? staro = null)
    {
        while (true)
        {
            int id = Ceo(naziv, staro, 1);
            if (postoji(id)) return id;
            Console.WriteLine("Ne postoji entitet sa tim ID-em.");
        }
    }

    // Lista Id-eva odvojenih zarezom, npr. "1,3,4".
    public static List<int> ListaIdeva(string naziv, Func<int, bool> postoji, List<int>? staro = null)
    {
        while (true)
        {
            string s = Citaj(naziv + " (odvojeni zarezom)", staro == null ? null : string.Join(",", staro));
            if (s == "" && staro != null) return new List<int>(staro);

            var rezultat = new List<int>();
            bool ispravno = s != "";
            foreach (string deo in s.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                if (int.TryParse(deo, out int id) && postoji(id)) { if (!rezultat.Contains(id)) rezultat.Add(id); }
                else ispravno = false;
            }
            if (ispravno && rezultat.Count > 0) return rezultat;
            Console.WriteLine("Unesite ispravne postojece ID-eve odvojene zarezom.");
        }
    }
}
