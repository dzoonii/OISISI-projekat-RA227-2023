# Sajam knjiga - prvi domaci zadatak

Konzolna C# aplikacija (.NET 8). Podaci se cuvaju u JSON fajlovima (folder `Podaci`, pored izvrsnog fajla).

## Autor
- Nikola Rogonjic, RA227/2023

## Struktura
- `Models/` - 6 entiteta (Posetilac, Autor, Knjiga, Kupovina, Izdavac, Adresa) + enum `StatusPosetioca`
  - Cuvaju se ID-evi (npr. `AdresaId`, `AutoriIds`), a liste objekata (npr. `Posetilac.Kupovine`,
    `Knjiga.Kupci`, `Autor.Knjige`) se ne cuvaju u fajlu nego se popunjavaju posle ucitavanja (`Podaci.Osvezi()`)
- `Dao/JsonDao.cs` - serijalizacija i deserijalizacija (jedan JSON fajl po entitetu)
- `Dao/Podaci.cs` - svih 6 DAO objekata na jednom mestu i popunjavanje lista
- `Meniji/` - prikaz, dodavanje, izmena i brisanje za svaki entitet (8.1 - 8.4), uz proveru zavisnosti pri brisanju
- `Unos.cs` - pomocne metode za unos i proveru podataka
- `Program.cs` - glavni meni

## Podela posla
| Clan tima | Kontrolna tacka 1 |
|---|---|
| Nikola Rogonjic (RA227/2023) | model, serijalizacija i konzolni CRUD za sve entitete |

## Pokretanje
Otvoriti `SajamKnjiga.sln` u Visual Studio-u (Ctrl+F5) ili u terminalu: `dotnet run`
