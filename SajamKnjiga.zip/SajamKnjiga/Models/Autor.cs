using System.Text.Json.Serialization;

namespace SajamKnjiga.Models;

public class Autor : Entitet
{
    public string Ime { get; set; } = "";
    public string Prezime { get; set; } = "";
    public DateTime DatumRodjenja { get; set; }
    public int AdresaId { get; set; }
    public string Telefon { get; set; } = "";
    public string Email { get; set; } = "";
    public string BrojLicneKarte { get; set; } = "";
    public int GodineIskustva { get; set; }

    // Lista objekata: NE cuva se u fajlu, popunjava je Podaci.Osvezi()
    [JsonIgnore] public List<Knjiga> Knjige { get; set; } = new();
}
