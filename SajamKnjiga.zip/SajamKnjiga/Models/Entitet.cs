namespace SajamKnjiga.Models;

// Zajednicka osnovna klasa: svaki entitet ima svoj Id.
public abstract class Entitet
{
    public int Id { get; set; }
}
