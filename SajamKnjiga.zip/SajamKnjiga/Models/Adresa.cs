namespace SajamKnjiga.Models;

public class Adresa : Entitet
{
    public string Ulica { get; set; } = "";
    public string Broj { get; set; } = "";
    public string Grad { get; set; } = "";
    public string Drzava { get; set; } = "";
}
