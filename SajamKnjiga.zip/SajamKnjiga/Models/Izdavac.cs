using System.Text.Json.Serialization;

namespace SajamKnjiga.Models;

public class Izdavac : Entitet
{
    public string Sifra { get; set; } = "";
    public string Naziv { get; set; } = "";
    public int SefId { get; set; }   // Id autora sa najmanje 5 godina iskustva

    // Liste objekata: NE cuvaju se u fajlu, popunjava ih Podaci.Osvezi()
    [JsonIgnore] public List<Autor> Autori { get; set; } = new();
    [JsonIgnore] public List<Knjiga> Knjige { get; set; } = new();
}
