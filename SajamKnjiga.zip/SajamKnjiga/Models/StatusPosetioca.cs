namespace SajamKnjiga.Models;

public enum StatusPosetioca
{
    R, // redovan
    V  // VIP
}
