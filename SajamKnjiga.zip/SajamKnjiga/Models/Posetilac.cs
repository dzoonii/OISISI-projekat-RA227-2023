using System.Text.Json.Serialization;

namespace SajamKnjiga.Models;

public class Posetilac : Entitet
{
    public string Ime { get; set; } = "";
    public string Prezime { get; set; } = "";
    public DateTime DatumRodjenja { get; set; }
    public int AdresaId { get; set; }
    public string Telefon { get; set; } = "";
    public string Email { get; set; } = "";
    public string BrojClanskeKarte { get; set; } = "";   // npr. CK-1-2023
    public int GodinaClanstva { get; set; }
    public StatusPosetioca Status { get; set; }
    public double ProsecnaOcena { get; set; }             // racuna se iz kupovina
    public List<int> ListaZeljaKnjigaIds { get; set; } = new();   // ovo se cuva u fajlu

    // Liste objekata: NE cuvaju se u fajlu, popunjava ih Podaci.Osvezi()
    [JsonIgnore] public List<Kupovina> Kupovine { get; set; } = new();
    [JsonIgnore] public List<Knjiga> ListaZelja { get; set; } = new();
}
